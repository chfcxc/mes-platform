﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Windows.Forms;

namespace V8Demo
{
    public partial class Form1 : Form
    {
        // appId
        private static String appId = "EUCP-XXX-XXXX-00000";
        // 密钥
        private static String secretKey = "XXXXXXXXXXXXXXXX";
        // 接口地址
        private static String host = "127.0.0.1:80";
        //参数压缩
        private bool isCompress = false;//是否压缩，默认否
        public Form1()
        {
            InitializeComponent();
        }

        #region 加密调用
        /// <summary>
        /// 单条提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                List<SMSEntity> SMSlist = new List<SMSEntity>();
                string result = "";
                Hashtable headerhs = new Hashtable();
                Byte[] byteArray = null;
                string jsondata = "";
                string url = "http://" + host + "/inter/sendSingleSMS";
                headerhs.Add("appId", appId);
                jsondata = " {\"mobile\":\"13444444444\",\"content\":\"【EMAY】短信内容 退订回复T\",\"timerTime\":\"\",\"extendedCode\":\"112\",\"customSmsId\":\"2017010709302911\",\"requestTime\":" + DateTime.Now.Ticks.ToString() + ",\"requestValidPeriod\":30}";
                if (isCompress)
                {
                    headerhs.Add("gzip", "on");//先压缩成byte再加密
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(GzipHelper.GZipCompressString(jsondata), secretKey), headerhs, Encoding.UTF8, secretKey);
                }
                else
                {
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(jsondata, secretKey), headerhs, Encoding.UTF8, secretKey);
                }

                if (byteArray != null)
                {
                    if (isCompress)
                    {
                        result = GzipHelper.DecompressString(AESHelper.AESDecrypt(byteArray, secretKey));
                    }
                    else
                    {
                        result = AESHelper.AESDecryptString(byteArray, secretKey);
                    }
                    if (result != "")
                    {
                        if (result.IndexOf("ERROR") != -1)
                        {
                            MessageBox.Show(result);
                        }
                        else
                        {
                            result = result.Replace('\"', '"');

                            JObject jo = (JObject)JsonConvert.DeserializeObject(result);
                            if (jo != null)
                            {
                                SMSEntity SMS = new SMSEntity();
                                SMS.customSmsId = jo["customSmsId"].ToString().Replace("\"", "");
                                SMS.mobile = jo["mobile"].ToString().Replace("\"", "");
                                SMS.smsId = jo["smsId"].ToString().Replace("\"", "");
                                SMSlist.Add(SMS);//返回状态报告对象结果集
                            }
                            MessageBox.Show("SUCCESS");
                        }
                        Logger.Write("单条提交:" + result);
                    }
                }
                else
                {
                    MessageBox.Show("单条提交异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }

        }
        /// <summary>
        /// 批量（SMSID）提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                List<SMSEntity> SMSlist = new List<SMSEntity>();
                string result = "";
                Hashtable headerhs = new Hashtable();
                Byte[] byteArray = null;
                string jsondata = "";
                string url = "http://" + host + "/inter/sendBatchSMS";

                headerhs.Add("appId", appId);
                jsondata = " {\"smses\":[{\"mobile\":\"15500000000\",\"customSmsId\":\"短信ID1\"},{\"mobile\":\"15500000001\",\"customSmsId\":\"短信ID2\"}],\"content\":\"【清华大学】i love you ! \",\"timerTime\":\"\",\"extendedCode\":\"112\",\"requestTime\":" + DateTime.Now.Ticks.ToString() + ",\"requestValidPeriod\":30}";

                if (isCompress)
                {
                    headerhs.Add("gzip", "on");//先压缩成byte再加密
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(GzipHelper.GZipCompressString(jsondata), secretKey), headerhs, Encoding.UTF8, secretKey);
                }
                else
                {
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(jsondata, secretKey), headerhs, Encoding.UTF8, secretKey);
                }

                if (byteArray != null)
                {
                    if (isCompress)
                    {
                        result = GzipHelper.DecompressString(AESHelper.AESDecrypt(byteArray, secretKey));
                    }
                    else
                    {
                        result = AESHelper.AESDecryptString(byteArray, secretKey);
                    }
                    if (result != "")
                    {
                        if (result.IndexOf("ERROR") != -1)
                        {
                            MessageBox.Show(result);
                        }
                        else
                        {
                            result = result.Replace('\"', '"');
                            Newtonsoft.Json.Linq.JArray Jarray = new JArray();
                            Jarray = (JArray)JsonConvert.DeserializeObject(result);
                            if (Jarray != null)
                            {
                                foreach (JObject j in Jarray)
                                {
                                    SMSEntity SMS = new SMSEntity();
                                    SMS.customSmsId = j["customSmsId"].ToString().Replace("\"", "");
                                    SMS.mobile = j["mobile"].ToString().Replace("\"", "");
                                    SMS.smsId = j["smsId"].ToString().Replace("\"", "");
                                    SMSlist.Add(SMS);//返回状态报告对象结果集
                                }
                                MessageBox.Show("SUCCESS");
                            }
                        }

                        Logger.Write(" 批量（SMSID）提交:" + result);
                    }
                }
                else
                {
                    MessageBox.Show("批量提交异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }
        /// <summary>
        /// 批量提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                List<SMSEntity> SMSlist = new List<SMSEntity>();
                string result = "";
                Hashtable headerhs = new Hashtable();
                Byte[] byteArray = null;
                string jsondata = "";
                string url = "http://" + host + "/inter/sendBatchOnlySMS";

                headerhs.Add("appId", appId);
                jsondata = " {\"mobiles\":[\"15500000000\",\"15500000001\"],\"content\":\"【短信签名】短信内容 \",\"timerTime\":\"\",\"extendedCode\":\"112\",\"requestTime\":" + DateTime.Now.Ticks.ToString() + ",\"requestValidPeriod\":30}";

                if (isCompress)
                {
                    headerhs.Add("gzip", "on");//先压缩成byte再加密
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(GzipHelper.GZipCompressString(jsondata), secretKey), headerhs, Encoding.UTF8, secretKey);
                }
                else
                {
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(jsondata, secretKey), headerhs, Encoding.UTF8, secretKey);
                }

                if (byteArray != null)
                {
                    if (isCompress)
                    {
                        result = GzipHelper.DecompressString(AESHelper.AESDecrypt(byteArray, secretKey));
                    }
                    else
                    {
                        result = AESHelper.AESDecryptString(byteArray, secretKey);
                    }
                    if (result != "")
                    {
                        if (result.IndexOf("ERROR") != -1)
                        {
                            MessageBox.Show(result);
                        }
                        else
                        {
                            result = result.Replace('\"', '"');
                            Newtonsoft.Json.Linq.JArray Jarray = new JArray();
                            Jarray = (JArray)JsonConvert.DeserializeObject(result);
                            if (Jarray != null)
                            {
                                foreach (JObject j in Jarray)
                                {
                                    SMSEntity SMS = new SMSEntity();
                                    SMS.customSmsId = j["customSmsId"].ToString().Replace("\"", "");
                                    SMS.mobile = j["mobile"].ToString().Replace("\"", "");
                                    SMS.smsId = j["smsId"].ToString().Replace("\"", "");
                                    SMSlist.Add(SMS);//返回状态报告对象结果集
                                }

                                MessageBox.Show("SUCCESS");
                            }
                        }


                        Logger.Write("批量提交:" + result);
                    }
                }
                else
                {
                    MessageBox.Show("批量提交异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }
        /// <summary>
        /// 个性提交
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;

                List<SMSEntity> SMSlist = new List<SMSEntity>();
                string result = "";
                Hashtable headerhs = new Hashtable();
                Byte[] byteArray = null;
                string jsondata = "";
                string url = "http://" + host + "/inter/sendPersonalitySMS";

                headerhs.Add("appId", appId);
                jsondata = "{\"smses\":[{\"mobile\":15500000000,\"customSmsId\":null,\"content\":\"【短信签名】短信内容\"},{\"mobile\":15500000001,\"customSmsId\":null,\"content\":\"【短信签名】短信内容\"}],\"timerTime\":\"\",\"extendedCode\":112,\"requestTime\":" + DateTime.Now.Ticks.ToString() + ",\"requestValidPeriod\":30}";

                if (isCompress)
                {
                    headerhs.Add("gzip", "on");//先压缩成byte再加密
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(GzipHelper.GZipCompressString(jsondata), secretKey), headerhs, Encoding.UTF8, secretKey);
                }
                else
                {
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(jsondata, secretKey), headerhs, Encoding.UTF8, secretKey);
                }

                if (byteArray != null)
                {
                    if (isCompress)
                    {
                        result = GzipHelper.DecompressString(AESHelper.AESDecrypt(byteArray, secretKey));
                    }
                    else
                    {
                        result = AESHelper.AESDecryptString(byteArray, secretKey);
                    }

                    if (result != "")
                    {   if (result.IndexOf("ERROR") != -1)
                        {
                            MessageBox.Show(result);
                        }
                        else
                        {
                        result = result.Replace('\"', '"');
                        Newtonsoft.Json.Linq.JArray Jarray = new JArray();
                        Jarray = (JArray)JsonConvert.DeserializeObject(result);
                        if (Jarray != null)
                        {
                            foreach (JObject j in Jarray)
                            {
                                SMSEntity SMS = new SMSEntity();
                                SMS.customSmsId = j["customSmsId"].ToString().Replace("\"", "");
                                SMS.mobile = j["mobile"].ToString().Replace("\"", "");
                                SMS.smsId = j["smsId"].ToString().Replace("\"", "");
                                SMSlist.Add(SMS);//返回短信对象结果集
                            }


                            MessageBox.Show("SUCCESS");
                        }
                        }

                    Logger.Write("个性提交:" + result);
                    }
                }
                else
                {
                    MessageBox.Show("个性提交异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }
        /// <summary>
        /// 获取状态报告
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                List<ReportEntity> reportlist = new List<ReportEntity>();
                string result = "";
                Hashtable headerhs = new Hashtable();
                Byte[] byteArray = null;
                string jsondata = "";
                string url = "http://" + host + "/inter/getReport";
                int ValidPeriod = 3600;
                headerhs.Add("appId", appId);
                jsondata = "{\"number\":3,\"requestTime\":" + DateTime.Now.Ticks.ToString() + ",\"requestValidPeriod\":" + ValidPeriod + "}";
                if (isCompress)
                {
                    headerhs.Add("gzip", "on");//先压缩成byte再加密
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(GzipHelper.GZipCompressString(jsondata), secretKey), headerhs, Encoding.UTF8, secretKey);
                }
                else
                {
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(jsondata, secretKey), headerhs, Encoding.UTF8, secretKey);
                }

                if (byteArray != null)
                {
                    if (isCompress)
                    {
                        result = GzipHelper.DecompressString(AESHelper.AESDecrypt(byteArray, secretKey));
                    }
                    else
                    {
                        result = AESHelper.AESDecryptString(byteArray, secretKey);
                    }
                    if (result != "")
                    {
                        if (result.IndexOf("ERROR") != -1)
                        {
                            MessageBox.Show(result);
                        }
                        else
                        {
                            result = result.Replace('\"', '"');
                            Newtonsoft.Json.Linq.JArray Jarray = new JArray();
                            Jarray = (JArray)JsonConvert.DeserializeObject(result);
                            if (Jarray != null)
                            {
                                foreach (JObject j in Jarray)
                                {
                                    ReportEntity report = new ReportEntity();
                                    report.customSmsId = j["customSmsId"].ToString().Replace("\"", "");
                                    report.desc = j["desc"].ToString().Replace("\"", "");
                                    report.extendedCode = j["extendedCode"].ToString().Replace("\"", "");
                                    report.mobile = j["mobile"].ToString().Replace("\"", "");
                                    report.receiveTime = j["receiveTime"].ToString().Replace("\"", "");
                                    report.smsId = j["smsId"].ToString().Replace("\"", "");
                                    report.state = j["state"].ToString().Replace("\"", "");
                                    report.submitTime = j["submitTime"].ToString().Replace("\"", "");
                                    reportlist.Add(report);//返回状态报告对象结果集
                                }
                            }
                        }

                        Logger.Write("获取状态报告:" + result);
                    }
                    else
                        Logger.Write("获取状态报告:无内容");
                }
                else
                {
                    MessageBox.Show("获取状态报告异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }
        /// <summary>
        /// 获取上行短信
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button6_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                List<MoEntity> molist = new List<MoEntity>();
                string result = "";
                Hashtable headerhs = new Hashtable();
                Byte[] byteArray = null;
                string jsondata = "";
                string url = "http://" + host + "/inter/getMo";
                int ValidPeriod = 3600;
                headerhs.Add("appId", appId);
                jsondata = "{\"number\":3,\"requestTime\":" + DateTime.Now.Ticks.ToString() + ",\"requestValidPeriod\":" + ValidPeriod + "}";
                if (isCompress)
                {
                    headerhs.Add("gzip", "on");//先压缩成byte再加密
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(GzipHelper.GZipCompressString(jsondata), secretKey), headerhs, Encoding.UTF8, secretKey);
                }
                else
                {
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(jsondata, secretKey), headerhs, Encoding.UTF8, secretKey);
                }
                if (byteArray != null)
                {
                    if (isCompress)
                    {
                        result = GzipHelper.DecompressString(AESHelper.AESDecrypt(byteArray, secretKey));
                    }
                    else
                    {
                        result = AESHelper.AESDecryptString(byteArray, secretKey);
                    }
                    if (result != "")
                    {
                        if (result.IndexOf("ERROR") != -1)
                        {
                            MessageBox.Show(result);
                        }
                        else
                        {
                            result = result.Replace('\"', '"');
                            Newtonsoft.Json.Linq.JArray Jarray = new JArray();
                            Jarray = (JArray)JsonConvert.DeserializeObject(result);
                            if (Jarray != null)
                            {
                                foreach (JObject j in Jarray)
                                {
                                    MoEntity mo = new MoEntity();
                                    mo.mobile = j["mobile"].ToString().Replace("\"", "");
                                    mo.content = j["content"].ToString().Replace("\"", "");
                                    mo.moTime = j["moTime"].ToString().Replace("\"", "");
                                    mo.extendedCode = j["extendedCode"].ToString().Replace("\"", "");
                                    molist.Add(mo);//返回MO对象结果集
                                }
                            }
                        }

                        Logger.Write("获取状态报告:" + result);
                    }
                    else
                        Logger.Write("获取上行:无内容");
                }
                else
                {
                    MessageBox.Show("上行短信异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }
        /// <summary>
        ///  查询余额
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button7_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                Hashtable headerhs = new Hashtable();
                Byte[] byteArray = null;
                string jsondata = "";
                string url = "http://" + host + "/inter/getBalance";
                int ValidPeriod = 3600;
                headerhs.Add("appId", appId);
                jsondata = "{\"requestTime\":" + DateTime.Now.Ticks.ToString() + ",\"requestValidPeriod\":" + ValidPeriod + "}";
                if (isCompress)
                {
                    headerhs.Add("gzip", "on");//先压缩成byte再加密
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(GzipHelper.GZipCompressString(jsondata), secretKey), headerhs, Encoding.UTF8, secretKey);
                }
                else
                {
                    byteArray = HttpHelper.postdata(url, AESHelper.AESEncrypt(jsondata, secretKey), headerhs, Encoding.UTF8, secretKey);
                }
                if (byteArray != null)
                {
                    JObject J = null;
                    if (isCompress)
                    {
                        J = (JObject)JsonConvert.DeserializeObject(GzipHelper.DecompressString(AESHelper.AESDecrypt(byteArray, secretKey)));
                    }
                    else
                    {
                        J = (JObject)JsonConvert.DeserializeObject(AESHelper.AESDecryptString(byteArray, secretKey));
                    }
                    if (J != null)
                        if (J["balance"] != null)
                            MessageBox.Show("余额：" + J["balance"].ToString());
                }
                else
                {
                    MessageBox.Show("查询余额异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }
        #endregion
        #region 普通调用


        private string ecodingJava(String str)
        {
            Encoding utf8 = Encoding.UTF8;
            Encoding defaultCode = Encoding.Default;
            byte[] utf8Bytes = defaultCode.GetBytes(str);
            byte[] defaultBytes = Encoding.Convert(utf8, defaultCode, utf8Bytes);
            char[] defaultChars = new char[defaultCode.GetCharCount(defaultBytes, 0, defaultBytes.Length)];
            defaultCode.GetChars(defaultBytes, 0, defaultBytes.Length, defaultChars, 0);
            return new string(defaultChars);
        }

        /// <summary>
        /// 发送短信
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button12_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                string SendContent = "发送内容%%";
                SendContent = Uri.EscapeDataString(SendContent);   //如内容中遇到“%”等特殊字符，先将参数转码
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                List<SMSEntity> SMSlist = new List<SMSEntity>();
                string jsondata = "";
                string url = "http://" + host + "/simpleinter/sendSMS";
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                Dictionary<string, string> parms = new Dictionary<string, string>();
                parms.Add("appId", appId);
                parms.Add("timestamp", timestamp);
                parms.Add("sign", Md5Helper.md5(appId + secretKey + timestamp, 32));
                parms.Add("timerTime", "");//定时发送时间
                parms.Add("customSmsId", "customSmsId");//自定义customSmsId选填
                parms.Add("extendedCode", "1");//扩展码
                parms.Add("mobiles", "13800000001,13800000002");//手机号半角逗号分隔
                parms.Add("content", SendContent);//手机号2与内容2对应

                jsondata = HttpHelper.postdata(url, parms, Encoding.UTF8);
                if (jsondata != "")
                {
                    if (jsondata != "-1")
                    {
                        JObject J = (JObject)JsonConvert.DeserializeObject(jsondata);
                        if (J != null)
                            if (J["code"] != null)
                                if (J["code"].ToString().Replace("\"", "") == "SUCCESS")
                                {
                                    if (J["data"] != null)
                                    {
                                        Newtonsoft.Json.Linq.JArray Jarray = new JArray();
                                        Jarray = (JArray)J["data"];
                                        if (Jarray != null)
                                        {
                                            foreach (JObject j in Jarray)
                                            {
                                                SMSEntity SMS = new SMSEntity();
                                                SMS.customSmsId = j["customSmsId"].ToString().Replace("\"", "");
                                                SMS.mobile = j["mobile"].ToString().Replace("\"", "");
                                                SMS.smsId = j["smsId"].ToString().Replace("\"", "");
                                                SMSlist.Add(SMS);//返回状态报告对象结果集
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(J["code"].ToString());
                                }
                    }
                    Logger.Write("普通调用:" + jsondata);
                }
                else
                {
                    MessageBox.Show("获取上行异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }

        /// <summary>
        /// 个性短信
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                List<SMSEntity> SMSlist = new List<SMSEntity>();
                string jsondata = "";
                string url = "http://" + host + "/simpleinter/sendPersonalitySMS";
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                Dictionary<string, string> parms = new Dictionary<string, string>();
                parms.Add("appId", appId);
                parms.Add("timestamp", timestamp);
                parms.Add("sign", Md5Helper.md5(appId + secretKey + timestamp, 32));
                parms.Add("timerTime", "");//定时发送时间，默认当前时间
                parms.Add("customSmsId", "customSmsId");//自定义customSmsId选填
                parms.Add("extendedCode", "11");//扩展码
                parms.Add("13800000000", Uri.EscapeDataString("内容1"));//手机号1与内容1对应
                parms.Add("13800000001", Uri.EscapeDataString("内容2"));//手机号2与内容2对应
                parms.Add("13800000002", Uri.EscapeDataString("内容3"));//手机号3与内容3对应
                parms.Add("13800000003", Uri.EscapeDataString("内容4"));//手机号4与内容4对应
                //。。。
                //。。。
                //。。。
                jsondata = HttpHelper.postdata(url, parms, Encoding.UTF8);
                if (jsondata != "")
                {
                    if (jsondata != "-1")
                    {
                        JObject J = (JObject)JsonConvert.DeserializeObject(jsondata);
                        if (J != null)
                            if (J["code"] != null)
                                if (J["code"].ToString().Replace("\"", "") == "SUCCESS")
                                {
                                    if (J["data"] != null)
                                    {
                                        Newtonsoft.Json.Linq.JArray Jarray = new JArray();
                                        Jarray = (JArray)J["data"];
                                        if (Jarray != null)
                                        {
                                            foreach (JObject j in Jarray)
                                            {
                                                SMSEntity SMS = new SMSEntity();
                                                SMS.customSmsId = j["customSmsId"].ToString().Replace("\"", "");
                                                SMS.mobile = j["mobile"].ToString().Replace("\"", "");
                                                SMS.smsId = j["smsId"].ToString().Replace("\"", "");
                                                SMSlist.Add(SMS);//返回状态报告对象结果集
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(J["code"].ToString());
                                }
                    }
                    Logger.Write("个性短信:" + jsondata);
                }
                else
                {
                    MessageBox.Show("获取上行异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }

        /// <summary>
        /// 获取状态报告
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                List<ReportEntity> reportlist = new List<ReportEntity>();
                string jsondata = "";
                string url = "http://" + host + "/simpleinter/getMo";
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                Dictionary<string, string> parms = new Dictionary<string, string>();
                parms.Add("appId", appId);
                parms.Add("timestamp", timestamp);
                parms.Add("sign", Md5Helper.md5(appId + secretKey + timestamp, 32));
                jsondata = HttpHelper.postdata(url, parms, Encoding.UTF8);
                if (jsondata != "")
                {
                    if (jsondata != "-1")
                    {
                        JObject J = (JObject)JsonConvert.DeserializeObject(jsondata);
                        if (J != null)
                            if (J["code"] != null)
                                if (J["code"].ToString().Replace("\"", "") == "SUCCESS")
                                {
                                    if (J["data"] != null)
                                    {
                                        Newtonsoft.Json.Linq.JArray Jarray = new JArray();
                                        Jarray = (JArray)J["data"];
                                        if (Jarray != null)
                                        {
                                            foreach (JObject j in Jarray)
                                            {
                                                ReportEntity report = new ReportEntity();
                                                report.customSmsId = j["customSmsId"].ToString().Replace("\"", "");
                                                report.desc = j["desc"].ToString().Replace("\"", "");
                                                report.extendedCode = j["extendedCode"].ToString().Replace("\"", "");
                                                report.mobile = j["mobile"].ToString().Replace("\"", "");
                                                report.receiveTime = j["receiveTime"].ToString().Replace("\"", "");
                                                report.smsId = j["smsId"].ToString().Replace("\"", "");
                                                report.state = j["state"].ToString().Replace("\"", "");
                                                report.submitTime = j["submitTime"].ToString().Replace("\"", "");
                                                reportlist.Add(report);//返回状态报告对象结果集
                                            }
                                        }

                                    }
                                }
                                else
                                {
                                    MessageBox.Show(J["code"].ToString());
                                }
                    }

                    Logger.Write("获取状态报告:" + jsondata);
                }
                else
                {
                    MessageBox.Show("获取状态报告异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }


        /// <summary>
        /// 获取上行
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                List<MoEntity> molist = new List<MoEntity>();
                string jsondata = "";
                string url = "http://" + host + "/simpleinter/getMo";
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                Dictionary<string, string> parms = new Dictionary<string, string>();
                parms.Add("appId", appId);
                parms.Add("timestamp", timestamp);
                parms.Add("sign", Md5Helper.md5(appId + secretKey + timestamp, 32));
                jsondata = HttpHelper.postdata(url, parms, Encoding.UTF8);
                if (jsondata != "")
                {
                    if (jsondata != "-1")
                    {
                        JObject J = (JObject)JsonConvert.DeserializeObject(jsondata);
                        if (J != null)
                            if (J["code"] != null)
                                if (J["code"].ToString().Replace("\"", "") == "SUCCESS")
                                {
                                    if (J["data"] != null)
                                    {
                                        Newtonsoft.Json.Linq.JArray Jarray = new JArray();
                                        Jarray = (JArray)J["data"];
                                        if (Jarray != null)
                                        {
                                            foreach (JObject j in Jarray)
                                            {
                                                MoEntity mo = new MoEntity();
                                                mo.mobile = j["mobile"].ToString().Replace("\"", "");
                                                mo.content = j["content"].ToString().Replace("\"", "");
                                                mo.moTime = j["moTime"].ToString().Replace("\"", "");
                                                mo.extendedCode = j["extendedCode"].ToString().Replace("\"", "");
                                                molist.Add(mo);//返回MO对象结果集
                                            }
                                        }

                                    }
                                }
                                else
                                {
                                    MessageBox.Show(J["code"].ToString());
                                }

                    }

                    Logger.Write("获取上行:" + jsondata);
                }
                else
                {
                    MessageBox.Show("获取上行异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }

        /// <summary>
        /// 查询余额
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "")
            {
                appId = textBox1.Text;
                secretKey = textBox2.Text;
                host = textBox3.Text;
                string jsondata = "";
                string url = "http://" + host + "/simpleinter/getBalance";
                string timestamp = DateTime.Now.ToString("yyyyMMddHHmmss");
                Dictionary<string, string> parms = new Dictionary<string, string>();
                parms.Add("appId", appId);
                parms.Add("timestamp", timestamp);
                parms.Add("sign", Md5Helper.md5(appId + secretKey + timestamp, 32));
                jsondata = HttpHelper.postdata(url, parms, Encoding.UTF8);
                if (jsondata != "")
                {
                    if (jsondata != "-1")
                    {
                        JObject J = (JObject)JsonConvert.DeserializeObject(jsondata);
                        if (J != null)
                            if (J["code"] != null)
                                if (J["code"].ToString().Replace("\"", "") == "SUCCESS")
                                {
                                    if (J["data"] != null)
                                    {

                                        MessageBox.Show("余额：" + J["data"]["balance"].ToString());
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(J["code"].ToString());
                                }

                    }

                }
                else
                {
                    MessageBox.Show("查询余额异常！");
                }
            }
            else
            {
                MessageBox.Show("必要参数不能为空值！");
            }
        }
        #endregion

    }
}
