﻿using System;
using Microsoft.Win32;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;

namespace V8Demo
{
    public class Logger
    {
        public static string logopen = System.Configuration.ConfigurationManager.AppSettings["logopen"].ToString();
        /// <summary>
        /// 向目录中写调试程序的日志文件
        /// </summary>
        /// <param name="log">日志内容</param>
        public static void Write(string log)
        {
            if (logopen == "TRUE")
            {
                string filepath = "";
                string DirectoryPath = Logger.GetLogFile();
                if (DirectoryPath != "")
                {
                    filepath = DirectoryPath + DateTime.Now.ToString("yyyyMMdd") + ".log";
                    Logger.isfile(filepath);
                }
                try
                {
                    StreamWriter sw = new StreamWriter(filepath, true);
                    sw.WriteLine(DateTime.Now.ToString() + ":    " + log);
                    sw.Close();
                }
                catch
                {
                    //Write("日志写入文件异常！");
                }
            }

        }
        private static string GetLogFile()
        {
            return  System.IO.Directory.GetCurrentDirectory();
           // return System.Configuration.ConfigurationManager.AppSettings["logfile"].ToString();
        }
        private static void isfile(string file)
        {
            if (File.Exists(file) == false)//如果不存在就创建文件
            {
                FileStream fs = File.Create(file);
                fs.Close();
                Thread.Sleep(100);
            }
        }
    }
}
