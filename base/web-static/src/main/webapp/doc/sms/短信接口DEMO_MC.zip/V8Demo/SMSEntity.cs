﻿using System;
using System.Collections.Generic;
using System.Text;

namespace V8Demo
{
    public class SMSEntity
    {
        public string mobile { get; set; }
        public string smsId { get; set; }
        public string customSmsId{ get; set; }
    }
}
