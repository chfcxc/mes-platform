﻿using System;
using System.Collections.Generic;

using System.Text;


namespace V8Demo
{
    public  class MoEntity
    {
        public string mobile { get; set; }
        public string content { get; set; }
        public string moTime { get; set; }
        public string extendedCode { get; set; }
    }
}
