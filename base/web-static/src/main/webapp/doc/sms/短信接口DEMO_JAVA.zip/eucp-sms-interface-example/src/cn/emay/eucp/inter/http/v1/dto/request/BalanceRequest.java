package cn.emay.eucp.inter.http.v1.dto.request;

import cn.emay.eucp.inter.http.v1.dto.request.BaseRequest;

/**
 * 请求Balance参数
 * @author Frank
 *
 */
public class BalanceRequest  extends BaseRequest {
	
	private static final long serialVersionUID = 1L;

}
