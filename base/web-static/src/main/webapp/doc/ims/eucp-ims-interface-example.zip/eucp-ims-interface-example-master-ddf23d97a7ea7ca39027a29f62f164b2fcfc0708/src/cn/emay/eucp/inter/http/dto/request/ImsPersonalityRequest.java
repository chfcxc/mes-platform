package cn.emay.eucp.inter.http.dto.request;

import cn.emay.eucp.inter.framework.dto.CustomImsIdAndMobileAndContent;



public class ImsPersonalityRequest extends ImsBaseRequest {

	private static final long serialVersionUID = 1L;

	private CustomImsIdAndMobileAndContent[] imses;

	public CustomImsIdAndMobileAndContent[] getImses() {
		return imses;
	}

	public void setImses(CustomImsIdAndMobileAndContent[] imses) {
		this.imses = imses;
	}

	

}
