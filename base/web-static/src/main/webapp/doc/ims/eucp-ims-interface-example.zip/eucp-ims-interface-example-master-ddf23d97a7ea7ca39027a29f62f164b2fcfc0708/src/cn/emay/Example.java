package cn.emay;

import java.util.Date;

import cn.emay.eucp.inter.framework.dto.CustomImsIdAndMobile;
import cn.emay.eucp.inter.framework.dto.CustomImsIdAndMobileAndContent;
import cn.emay.eucp.inter.http.dto.request.ImsBatchRequest;
import cn.emay.eucp.inter.http.dto.request.ImsPersonalityRequest;
import cn.emay.eucp.inter.http.dto.request.ImsReportRequest;
import cn.emay.eucp.inter.http.dto.request.ImsSingleRequest;
import cn.emay.eucp.inter.http.dto.response.ImsResponse;
import cn.emay.eucp.inter.http.dto.response.ReportResponse;
import cn.emay.eucp.inter.http.dto.response.ResponseData;
import cn.emay.util.DateUtil;
import cn.emay.util.JsonHelper;
import cn.emay.util.Md5;
import cn.emay.util.http.HttpClient;
import cn.emay.util.http.HttpRequest;
import cn.emay.util.http.HttpRequestBytes;
import cn.emay.util.http.HttpRequestParams;
import cn.emay.util.http.HttpResponseBytes;
import cn.emay.util.http.HttpResponseBytesPraser;
import cn.emay.util.http.HttpResultCode;
import cn.emay.util.http.HttpsRequestBytes;

import com.google.gson.reflect.TypeToken;

public class Example {

	public static void main(String[] args) {
		// appId
		String appId = "EUCP-EMY-IMS1-PIC19";// 请联系销售，或者在页面中 获取
		// 密钥
		String secretKey = "E034902E517531F3";// 请联系销售，或者在页面中 获取
		// 接口地址
		// String host = "http://emay.com";// 请联系销售获取
		String host = "http://127.0.0.1:8999";
		// 时间戳
		String timestamp = DateUtil.toString(new Date(), "yyyyMMddHHmmss");
		// 签名
		String sign = Md5.md5((appId + secretKey + timestamp).getBytes());

		// 发送单条短信
		sendSingleIMS(appId, host, "This is a text message to Australia", "2018010709302911", "0061422118000", timestamp, sign);

		// 发送批次短信[有自定义SMSID]
		sendBatchIMS(appId, host, "This is a text message to Australia", new CustomImsIdAndMobile[] { new CustomImsIdAndMobile("1", "0061422118000"), new CustomImsIdAndMobile("2", "0061422118001") },
				timestamp, sign);

		// 发送全个性短信
		sendPersonalityIMS(appId, host, new CustomImsIdAndMobileAndContent[] { new CustomImsIdAndMobileAndContent("1", "0061422118000", "This is a personality message to Australia"),
				new CustomImsIdAndMobileAndContent("2", "0061422118001", " This is a text message to Australia") }, timestamp, sign);

		// 获取状态报告
		getIMSReport(appId, host, timestamp, sign, 500);
	}

	/**
	 * 发送单条短信
	 * 
	 * @param appId
	 * @param secretKey
	 * @param host
	 * @param content
	 * @param customImsId
	 * @param mobile
	 * @param timestamp
	 * @param sign
	 */
	private static void sendSingleIMS(String appId, String host, String content, String customImsId, String mobile, String timestamp, String sign) {
		System.out.println("=============begin sendSingleIMS==================");
		ImsSingleRequest pamars = new ImsSingleRequest();
		pamars.setAppId(appId);
		pamars.setContent(content);
		pamars.setCustomImsId(customImsId);
		pamars.setMobile(mobile);
		pamars.setTimestamp(timestamp);
		pamars.setSign(sign);
		String json = request(pamars, host + "/inter/sendSingleIMS");
		if (json != null) {
			ResponseData<ImsResponse> data = JsonHelper.fromJson(new TypeToken<ResponseData<ImsResponse>>() {
			}, json);
			String code = data.getCode();
			if ("SUCCESS".equals(code)) {
				System.out.println("result data:" + data.getData().getMobile() + "," + data.getData().getImsId() + "," + data.getData().getCustomImsId());
			}
		}
		System.out.println("=============end sendSingleIMS==================");
	}

	/**
	 * 发送批次短信
	 * 
	 * @param appId
	 * @param host
	 * @param content
	 * @param customImsIdAndMobiles
	 * @param timestamp
	 * @param sign
	 */
	private static void sendBatchIMS(String appId, String host, String content, CustomImsIdAndMobile[] customImsIdAndMobiles, String timestamp, String sign) {
		System.out.println("=============begin sendBatchIMS==================");
		ImsBatchRequest pamars = new ImsBatchRequest();
		pamars.setImses(customImsIdAndMobiles);
		pamars.setContent(content);
		pamars.setAppId(appId);
		pamars.setTimestamp(timestamp);
		pamars.setSign(sign);
		String json = request(pamars, host + "/inter/sendBatchIMS");
		if (json != null) {
			ResponseData<ImsResponse[]> data = JsonHelper.fromJson(new TypeToken<ResponseData<ImsResponse[]>>() {
			}, json);
			String code = data.getCode();
			if ("SUCCESS".equals(code)) {
				for (ImsResponse imsResponse : data.getData()) {
					System.out.println("result data:" + imsResponse.getMobile() + "," + imsResponse.getImsId() + "," + imsResponse.getCustomImsId());
				}
			}
		}
		System.out.println("=============end sendBatchIMS==================");
	}

	/**
	 * 发送个性短信
	 * 
	 * @param appId
	 * @param host
	 * @param customImsIdAndMobileAndContents
	 * @param timestamp
	 * @param sign
	 */
	private static void sendPersonalityIMS(String appId, String host, CustomImsIdAndMobileAndContent[] customImsIdAndMobileAndContents, String timestamp, String sign) {
		System.out.println("=============begin sendPersonalityIMS==================");
		ImsPersonalityRequest pamars = new ImsPersonalityRequest();
		pamars.setImses(customImsIdAndMobileAndContents);
		pamars.setAppId(appId);
		pamars.setTimestamp(timestamp);
		pamars.setSign(sign);
		String json = request(pamars, host + "/inter/sendPersonalityIMS");
		if (json != null) {
			ResponseData<ImsResponse[]> data = JsonHelper.fromJson(new TypeToken<ResponseData<ImsResponse[]>>() {
			}, json);
			String code = data.getCode();
			if ("SUCCESS".equals(code)) {
				for (ImsResponse imsResponse : data.getData()) {
					System.out.println("result data:" + imsResponse.getMobile() + "," + imsResponse.getImsId() + "," + imsResponse.getCustomImsId());
				}
			}
		}
		System.out.println("=============end sendPersonalityIMS==================");
	}

	/**
	 * 获取状态报告
	 * 
	 * @param appId
	 * @param host
	 * @param timestamp
	 * @param sign
	 * @param number
	 */
	private static void getIMSReport(String appId, String host, String timestamp, String sign, int number) {
		System.out.println("=============begin getIMSReport==================");
		ImsReportRequest pamars = new ImsReportRequest();
		pamars.setAppId(appId);
		pamars.setTimestamp(timestamp);
		pamars.setSign(sign);
		pamars.setNumber(number);
		String json = request(pamars, host + "/inter/getIMSReport");
		if (json != null) {
			ResponseData<ReportResponse[]> data = JsonHelper.fromJson(new TypeToken<ResponseData<ReportResponse[]>>() {
			}, json);
			String code = data.getCode();
			if ("SUCCESS".equals(code)) {
				for (ReportResponse reportResponse : data.getData()) {
					System.out.println("result data:" + reportResponse.getMobile() + "," + reportResponse.getImsId() + "," + reportResponse.getCustomImsId());
				}
			}
		}
		System.out.println("=============end getIMSReport==================");
	}

	/**
	 * 公共请求方法
	 */
	public static String request(Object requestParams, String url) {
		HttpRequest<byte[]> request = null;
		try {
			String requestJson = JsonHelper.toJsonString(requestParams);
			System.out.println("request json: " + requestJson);
			byte[] bytes = requestJson.getBytes("UTF-8");
			System.out.println("request data size : " + bytes.length);
			HttpRequestParams<byte[]> params = new HttpRequestParams<byte[]>();
			params.setCharSet("UTF-8");
			params.setMethod("POST");
			params.setParams(bytes);
			params.setUrl(url);
			if (url.startsWith("https://")) {
				request = new HttpsRequestBytes(params, null);
			} else {
				request = new HttpRequestBytes(params);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		HttpClient client = new HttpClient();
		String code = null;
		String json = null;
		try {
			HttpResponseBytes res = client.service(request, new HttpResponseBytesPraser());
			if (res == null) {
				System.out.println("请求接口异常");
				return null;
			}
			if (res.getResultCode().equals(HttpResultCode.SUCCESS)) {
				if (res.getHttpCode() == 200) {
					code = res.getResultCode().getCode();
					if (code.equals("SUCCESS")) {
						byte[] data = res.getResult();
						System.out.println("response data size : " + data.length);
						json = new String(data, "UTF-8");
						System.out.println("response json: " + json);
					}
				} else {
					System.out.println("请求接口异常,请求码:" + res.getHttpCode());
				}
			} else {
				System.out.println("请求接口网络异常:" + res.getResultCode().getCode());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return json;
	}

}
