package cn.emay.demo;

import cn.emay.util.HttpClient;
import cn.emay.util.HttpClient.HttpMethod;
import cn.emay.util.HttpErrorException;
import cn.emay.util.HttpRequestBody;
import cn.emay.util.HttpResponseBody;
import cn.emay.util.Md5;

/**
 * 余额获取
 *
 * @author IYU
 * @date 2018年5月11日
 * 
 */

public class testBalance {

	public static void main(String[] args) {

		balance();
	}

	private static void balance() {
		String appId = "EUCP-EMY-VOC1-I9XJ0";
		String secretKey = "46759718E7487595";
		String signStr = appId + secretKey;
		System.out.println("加密前sign:" + signStr);
		String sign = Md5.md5(signStr.getBytes());
		System.out.println("加密后sign:" + sign);

		String reqstr = "appId=" + appId + "&" + "sign=" + sign;
		System.out.println(reqstr);
		String url = "http://100.100.10.82:8999/voice/getBalance";
		HttpClient client = new HttpClient(60, 60, true);
		HttpRequestBody body;
		try {
			body = new HttpRequestBody(url, "UTF-8", reqstr, HttpMethod.POST, null, null);
		} catch (HttpErrorException e) {
			e.printStackTrace();
			return;
		}
		HttpResponseBody res = client.service(body);
		if (res.isSuccess() && res.getCode() == 200) {
			String rs1 = res.getResultString();
			System.out.println("获取余额收到响应报文" + rs1);
		}
	}

}
