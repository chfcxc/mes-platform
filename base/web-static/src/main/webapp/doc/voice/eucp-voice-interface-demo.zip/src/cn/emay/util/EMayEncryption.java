package cn.emay.util;


import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;

public class EMayEncryption {

	public static void main(String[] args) throws Exception {
		String str = "1234567";
		String password = "sdiekdo3348238ii";
		String ase = aesEncrypt(str, password);
		String st = aesDecrypt(ase, password);
		System.out.println(ase);
		System.out.println(st);
		System.out.println(md5(str));
	}
	
	public static String md5(String str){
		return DigestUtils.md5Hex(str);
	}

	
	public static String aesEncrypt(String str, String password) {
		if (str == null || password == null)
			return null;
		try {
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE,
					new SecretKeySpec(password.getBytes("utf-8"), "AES"));
			byte[] bytes = cipher.doFinal(str.getBytes("utf-8"));
			return org.apache.commons.codec.binary.Base64.encodeBase64String(bytes);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static String aesDecrypt(String str, String password){
		if (str == null || password == null)
			return null;
		try {
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE,
					new SecretKeySpec(password.getBytes("utf-8"), "AES"));
			byte[] bytes = Base64.decodeBase64(str);
			bytes = cipher.doFinal(bytes);
			return new String(bytes, "utf-8");
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}	
	
}
