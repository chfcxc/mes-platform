package cn.emay.demo;

import java.util.Date;

import cn.emay.util.DateUtil;
import cn.emay.util.HttpClient;
import cn.emay.util.HttpClient.HttpMethod;
import cn.emay.util.HttpErrorException;
import cn.emay.util.HttpRequestBody;
import cn.emay.util.HttpResponseBody;
import cn.emay.util.Md5;

/**
 * 验证码
 * 
 * @author IYU
 * @date 2018年5月11日
 * 
 */

public class testSendVerify {

	public static void main(String[] args) {

		send();
	}

	private static void send() {
		String appId = "EUCP-EMY-VOC1-I9XJ0";
		String timestamp = DateUtil.toString(new Date(), "yyyyMMddHHmmss");
		String secretKey = "46759718E7487595";
		String signStr = appId + secretKey + timestamp;
		System.out.println("加密前sign:" + signStr);
		String sign = Md5.md5(signStr.getBytes());
		System.out.println("加密后sign:" + sign);
		String content = "1234";
		String mobile = "17611000060";
		String customVoiceId = "1";

		String reqstr = "appId=" + appId + "&" + "timestamp=" + timestamp + "&" + "sign=" + sign + "&" + "mobile=" + mobile + "&" + "content=" + content + "&" + "customVoiceId=" + customVoiceId;
		System.out.println(reqstr);
		String url = "http://127.0.0.1:8999/voice/sendVFCode";
		HttpClient client = new HttpClient(60, 60, true);
		HttpRequestBody body;
		try {
			body = new HttpRequestBody(url, "UTF-8", reqstr, HttpMethod.POST, null, null);
		} catch (HttpErrorException e) {
			e.printStackTrace();
			return;
		}
		HttpResponseBody res = client.service(body);
		if (res.isSuccess() && res.getCode() == 200) {
			String rs1 = res.getResultString();
			System.out.println("发送短信收到响应报文" + rs1);
		}
	}
}
