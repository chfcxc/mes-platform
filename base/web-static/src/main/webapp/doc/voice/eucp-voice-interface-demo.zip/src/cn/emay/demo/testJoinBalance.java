package cn.emay.demo;

import cn.emay.util.HttpClient;
import cn.emay.util.HttpErrorException;
import cn.emay.util.HttpRequestBody;
import cn.emay.util.HttpResponseBody;
import cn.emay.util.Md5;
import cn.emay.util.HttpClient.HttpMethod;

/** @创建人：dejun  
 * 
 * @创建时间：2019年4月12日 下午5:03:19   @修改人：dejun  
 * @修改时间：2019年4月12日 下午5:03:19   @修改备注： */

public class testJoinBalance {

	public static void main(String[] args) {

		balance();
	}

	private static void balance() {
		String appId = "EUCP-EMY-VOC1-I9XJ0";
		String secretKey = "46759718E7487595";
		String signStr = appId + secretKey;
		System.out.println("加密前sign:" + signStr);
		String sign = Md5.md5(signStr.getBytes());
		System.out.println("加密后sign:" + sign);

		String reqstr = "appId=" + appId + "&" + "sign=" + sign;
		System.out.println(reqstr);
		String url = "http://100.100.10.82:8999/voice/getBalance";
		HttpClient client = new HttpClient(60, 60, true);
		HttpRequestBody body;
		try {
			body = new HttpRequestBody(url, "UTF-8", reqstr, HttpMethod.POST, null, null);
		} catch (HttpErrorException e) {
			e.printStackTrace();
			return;
		}
		HttpResponseBody res = client.service(body);
		if (res.isSuccess() && res.getCode() == 200) {
			String rs1 = res.getResultString();
			System.out.println("获取余额收到响应报文" + rs1);
		}
	}

}
