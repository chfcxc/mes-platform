package cn.emay.demo;

import java.util.Date;

import cn.emay.util.DateUtil;
import cn.emay.util.HttpClient;
import cn.emay.util.HttpClient.HttpMethod;
import cn.emay.util.HttpErrorException;
import cn.emay.util.HttpRequestBody;
import cn.emay.util.HttpResponseBody;
import cn.emay.util.Md5;

/**
 * 通知
 * 
 * @author IYU
 * @date 2018年5月11日
 * 
 */

public class testSendNotify {

	public static void main(String[] args) {

		send();
	}

	private static void send() {
		String appId = "EUCP-EMY-VOC1-DE7OI";
		String timestamp = DateUtil.toString(new Date(), "yyyyMMddHHmmss");
		String secretKey = "27B30D75C8F523D9";
		String signStr = appId + secretKey + timestamp;
		System.out.println("加密前sign:" + signStr);
		String sign = Md5.md5(signStr.getBytes());
		System.out.println("加密后sign:" + sign);
		String content = "消息内容";
		String mobiles = "17611000060,18141915561";
		String customVoiceIds = "1,2";
		String isInteractive = "1";
		// 互动内容
		String interactiveContent = "132131231";
		// 留言内容
		String acousticSignContent = "1111";

		String reqstr = "appId=" + appId + "&" + "timestamp=" + timestamp + "&" + "sign=" + sign + "&" + "mobiles=" + mobiles + "&" + "content=" + content + "&" + "customVoiceIds=" + customVoiceIds+ "&isInteractive="
				+ isInteractive + "&interactiveContent=" + interactiveContent + "&acousticSignContent=" + acousticSignContent;
		System.out.println(reqstr);
//		String url = "http://127.0.0.1:8999/voice/send";
		String url = "http://100.100.10.82:8999/voice/send";
		HttpClient client = new HttpClient(60, 60, true);
		HttpRequestBody body;
		try {
			body = new HttpRequestBody(url, "UTF-8", reqstr, HttpMethod.POST, null, null);
		} catch (HttpErrorException e) {
			e.printStackTrace();
			return;
		}
		HttpResponseBody res = client.service(body);
		if (res.isSuccess() && res.getCode() == 200) {
			String rs1 = res.getResultString();
			System.out.println("发送短信收到响应报文" + rs1);
		}
	}
}
