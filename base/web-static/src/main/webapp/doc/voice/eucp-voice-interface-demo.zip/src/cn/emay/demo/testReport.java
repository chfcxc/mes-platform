package cn.emay.demo;

import java.util.Date;

import cn.emay.util.DateUtil;
import cn.emay.util.HttpClient;
import cn.emay.util.HttpClient.HttpMethod;
import cn.emay.util.HttpErrorException;
import cn.emay.util.HttpRequestBody;
import cn.emay.util.HttpResponseBody;
import cn.emay.util.Md5;

/**
 * 状态报告获取
 * 
 * @author IYU
 * @date 2018年5月11日
 * 
 */

public class testReport {

	public static void main(String[] args) {

		report();
	}

	private static void report() {
		String appId = "EUCP-EMY-VOC1-I9XJ0";
		String timestamp = DateUtil.toString(new Date(), "yyyyMMddHHmmss");
		String secretKey = "46759718E7487595";
		String signStr = appId + secretKey + timestamp;
		System.out.println("加密前sign:" + signStr);
		String sign = Md5.md5(signStr.getBytes());
		System.out.println("加密后sign:" + sign);
		Integer number = 10;

		String reqstr = "appId=" + appId + "&" + "timestamp=" + timestamp + "&" + "sign=" + sign + "&" + "number=" + number;
		System.out.println(reqstr);
		String url = "http://127.0.0.1:8999/voice/getReport";
		HttpClient client = new HttpClient(60, 60, true);
		HttpRequestBody body;
		try {
			body = new HttpRequestBody(url, "UTF-8", reqstr, HttpMethod.POST, null, null);
		} catch (HttpErrorException e) {
			e.printStackTrace();
			return;
		}
		HttpResponseBody res = client.service(body);
		if (res.isSuccess() && res.getCode() == 200) {
			String rs1 = res.getResultString();
			System.out.println("获取状态报告收到响应报文" + rs1);
		}
	}

}
