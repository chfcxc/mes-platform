package cn.emay.demo;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import cn.emay.util.DateUtil;
import cn.emay.util.HttpClient;
import cn.emay.util.HttpErrorException;
import cn.emay.util.HttpRequestBody;
import cn.emay.util.HttpResponseBody;
import cn.emay.util.Md5;
import cn.emay.util.HttpClient.HttpMethod;

/** 互动
 * 
 * @author dejun */
public class TestJoinSendInteractive {

	public static void main(String[] args) {

		send();
	}

	private static void send() {
		String appId = "EUCP-EMY-VOC0-BBOR7";
		String timestamp = DateUtil.toString(new Date(), "yyyyMMddHHmmss");
		String secretKey = "4EBAF0EABB31FF29";
		String signStr = appId + secretKey + timestamp;
		System.out.println("加密前sign:" + signStr);
		String sign = Md5.md5(signStr.getBytes());
		System.out.println("加密后sign:" + sign);//
		String mobiles = "15350706525";//
		String customJoinIds = "4567891230";
		Map<String, String> param = new HashMap<String, String>();
		param.put("appId", appId);
		param.put("timestamp", timestamp);
		param.put("sign", sign);
		param.put("isInteractive", "0");
		param.put("isAcousticSign", "0");
		param.put("interactiveContent", "了解详情请按8");
		param.put("acousticSignContent", "请问您还有什么其他问题需要帮助？");//
		param.put("voiceContent", "12312adadfasf阿达");
		param.put("smsContent", "大萨达稍等阿萨德123124asda阿达");
		param.put("triggerConditions", "3");
		param.put("keyContent", "4");
		param.put("mobiles", mobiles);
		param.put("customJoinId", customJoinIds);
		String url = "http://127.0.0.1:8999/join/send";

		// 组装报文发送
		HttpClient client = new HttpClient(60, 60, true);
		HttpRequestBody body;
		try {
			body = new HttpRequestBody(url, "UTF-8", HttpMethod.POST, null, null, param);
		} catch (HttpErrorException e) {
			e.printStackTrace();
			return;
		}
		HttpResponseBody res = client.service(body);
		if (res.isSuccess() && res.getCode() == 200) {
			String rs1 = res.getResultString();
			System.out.println("发送短信收到响应报文" + rs1);
		}
	}

}
