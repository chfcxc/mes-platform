package cn.emay.exec;

import org.eclipse.jetty.server.HttpConfiguration;
import org.eclipse.jetty.server.HttpConnectionFactory;
import org.eclipse.jetty.server.SecureRequestCustomizer;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.ServerConnector;
import org.eclipse.jetty.server.SslConnectionFactory;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.util.ssl.SslContextFactory;
import org.eclipse.jetty.webapp.WebAppContext;

public class HttpsServer {

	public static void main(String[] args) {
		Server server = new Server();

		HttpConfiguration https_config = new HttpConfiguration();
		https_config.setSecureScheme("https");
		https_config.setSecurePort(8443);
		https_config.setOutputBufferSize(32768);
		SecureRequestCustomizer secureRequestCustomizer = new SecureRequestCustomizer();
		https_config.addCustomizer(secureRequestCustomizer);

		SslContextFactory sslContextFactory = new SslContextFactory();
		// The configured keystore to use for all SSL/TLS in configured Jetty Connector (or Client).
		sslContextFactory.setKeyStorePath("D:/test.keystore");
		// This is used if validating client certificates and is typically set to the same path as the keystore.
		sslContextFactory.setTrustStorePath("D:/test.keystore");
		sslContextFactory.setKeyStorePassword("123456");
		sslContextFactory.setKeyManagerPassword("123456");
		sslContextFactory.setTrustStorePassword("123456");
		// sslContextFactory.setWantClientAuth(true);
		ServerConnector httpsConnector = new ServerConnector(server, new SslConnectionFactory(sslContextFactory, "http/1.1"), new HttpConnectionFactory(https_config));
		httpsConnector.setPort(8088);
		httpsConnector.setIdleTimeout(500000);
		server.addConnector(httpsConnector);

		WebAppContext webApp = new WebAppContext();
		webApp = new WebAppContext();
		webApp.setContextPath("/");
		webApp.setResourceBase("WebRoot");
		webApp.setInitParameter("org.eclipse.jetty.servlet.Default.dirAllowed", "false");
		webApp.setInitParameter("org.eclipse.jetty.servlet.Default.useFileMappedBuffer", "false");
		webApp.addServlet(new ServletHolder(new ReceiveReportServlet()), ReceiveReportServlet.path);
		webApp.addServlet(new ServletHolder(new ReceiveGzipReportServlet()), ReceiveGzipReportServlet.path);
		webApp.setMaxFormContentSize(10000000);
		server.setHandler(webApp);

		try {
			server.start();
			System.out.println("start....");
			server.join();
			System.out.println("join....");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
