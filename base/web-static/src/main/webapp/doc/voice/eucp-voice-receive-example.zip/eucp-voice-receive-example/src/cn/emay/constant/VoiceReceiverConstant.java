package cn.emay.constant;

public class VoiceReceiverConstant {

	public static final String secretKey = "696CE880EF8A2EE0";

	public static String algorithm = "AES/ECB/PKCS5Padding";

}
